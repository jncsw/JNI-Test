	package com.sdu.nativecode;  
	  
	public class TestNativeCode {  
	    // �������ط���  
	    public native void sayHello();  
	    public static void main(String[] args) {  
	      // ���ض�̬���ӿ�  
	      System.loadLibrary("nativeCode");  
	      TestNativeCode nativeCode = new TestNativeCode();  
	      nativeCode.sayHello();  
	  
	    }  
	}  
